import JoinNow from "../../components/JoinNow/JoinNow"
function Register() {
  return (
    <JoinNow/>
  )
}

export default Register